#!/bin/zsh
# Unapproved USB Drive Alert Script
# Displays a warning notification via JAMF Helper when an unapproved
# removable drive is detected by Jamf Protect
#
# Version: 1.0
# Created for: HCS Technology Group

# Variables
jamfHelper="/Library/Application Support/JAMF/bin/jamfHelper.app/Contents/MacOS/jamfHelper"
icon="/Library/Application Support/JAMF/HCS.png"
title="HCS Technology Group"
heading="Unapproved Storage Device Detected"
description="You have connected an external storage device that is not on the approved list. This device has been blocked for security purposes. If you require access to use this device for work, please contact the IT team for assistance."
button1="OK"

# Display the notification using JAMF Helper
"$jamfHelper" -windowType utility \
   -icon "$icon" \
   -title "$title" \
   -heading "$heading" \
   -description "$description" \
   -button1 "$button1" \
   -defaultButton 1

exit 0
